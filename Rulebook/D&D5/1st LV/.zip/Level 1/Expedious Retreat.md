Source: Player's Handbook

_1st-level transmutation_

**Casting Time:** 1 bonus action  
**Range:** Self  
**Components:** V, S  
**Duration:** Concentration, up to 10 minutes

This spell allows you to move at an incredible pace. When you cast this spell, and then as a bonus action on each of your turns until the spell ends, you can take the Dash action.

**_Spell Lists._** [Artificer](http://dnd5e.wikidot.com/spells:artificer), [Sorcerer](http://dnd5e.wikidot.com/spells:sorcerer), [Warlock](http://dnd5e.wikidot.com/spells:warlock), [Wizard](http://dnd5e.wikidot.com/spells:wizard)