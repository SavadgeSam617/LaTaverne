Source: Player's Handbook

_1st-level evocation_

**Casting Time:** 1 bonus action  
**Range:** Self  
**Components:** V, S  
**Duration:** Concentration, up to 1 minute

Your prayer empowers you with divine radiance. Until the spell ends, your weapon attacks deal an extra 1d4 radiant damage on a hit.

**_Spell Lists._** [Paladin](http://dnd5e.wikidot.com/spells:paladin)