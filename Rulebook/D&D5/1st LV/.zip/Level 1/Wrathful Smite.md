_1st-level evocation_

**Casting Time:** 1 bonus action  
**Range:** Self  
**Components:** V  
**Duration:** Concentration, up to 1 minute

The next time you hit with a melee weapon attack during this spell’s duration, your attack deals an extra 1d6 psychic damage. Additionally, if the target is a creature, it must make a Wisdom saving throw or be frightened of you until the spell ends. As an action, the creature can make a Wisdom check against your spell save DC to steel its resolve and end this spell.

**_Spell Lists._** [Paladin](http://dnd5e.wikidot.com/spells:paladin)