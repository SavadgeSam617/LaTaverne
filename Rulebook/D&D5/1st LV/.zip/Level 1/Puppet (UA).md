Source: Unearthed Arcana 36 - Starter Spells

_1st-level enchantment_

**Casting Time:** 1 action  
**Range:** 120 feet  
**Components:** V  
**Duration:** Instantaneous

Your gesture forces one humanoid you can see within range to make a Constitution saving throw. On a failed save, the target must move up to its speed in a direction you choose. In addition, you can cause the target to drop whatever it is holding. This spell has no effect on a humanoid that is immune to being charmed.

**_Spell Lists._** [Bard](http://dnd5e.wikidot.com/spells:bard), [Warlock](http://dnd5e.wikidot.com/spells:warlock), [Wizard](http://dnd5e.wikidot.com/spells:wizard)