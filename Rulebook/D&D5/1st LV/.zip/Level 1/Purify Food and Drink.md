Source: Player's Handbook

_1st-level transmutation (ritual)_

**Casting Time:** 1 action  
**Range:** 10 feet  
**Components:** V, S  
**Duration:** Instantaneous

All nonmagical food and drink within a 5-foot-radius sphere centered on a point of your choice within range is purified and rendered free of poison and disease.

**_Spell Lists._** [Artificer](http://dnd5e.wikidot.com/spells:artificer), [Cleric](http://dnd5e.wikidot.com/spells:cleric), [Druid](http://dnd5e.wikidot.com/spells:druid), [Paladin](http://dnd5e.wikidot.com/spells:paladin)