_1st-level enchantment_

**Casting Time:** 1 bonus action  
**Range:** 10 feet  
**Components:** V  
**Duration:** Instantaneous

Each sleeping creature you choose within range awakens, and then each prone creature within range can stand up without expending any movement.

**_Spell Lists._** [Bard](http://dnd5e.wikidot.com/spells:bard), [Ranger](http://dnd5e.wikidot.com/spells:ranger), [Sorcerer](http://dnd5e.wikidot.com/spells:sorcerer), [Wizard](http://dnd5e.wikidot.com/spells:wizard)