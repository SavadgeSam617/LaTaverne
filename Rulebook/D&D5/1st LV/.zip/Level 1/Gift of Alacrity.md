Source: Explorer's Guide to Wildemount

_1st-level divination (dunamancy:chronurgy)_

**Casting Time:** 1 minute  
**Range:** Touch  
**Components:** V, S  
**Duration:** 8 hours

You touch a willing creature. For the duration, the target can add 1d8 to its initiative rolls.

**_Spell Lists._** [Wizard (Dunamancy)](http://dnd5e.wikidot.com/spells:wizard)