Source: Acquisitions Inc.

_1st-level Illusion_

**Casting Time:** 1 minute  
**Range:** Touch  
**Components:** V  
**Duration:** 8 hours

You cast this spell on an object no more than 1 foot on a side, doubling the object's perceived value by adding illusionary flourish or reducing its perceived value by half with the help of illusionary dents and scratches. Anyone examining the object must roll an Investigation check against your spell DC.

**_At Higher Levels._** When you cast this spell using a higher spell slot, you increase the size of the object by 1 foot per spell slot over 1st.

**_Spell Lists._** [Bard](http://dnd5e.wikidot.com/spells:bard), [Sorcerer](http://dnd5e.wikidot.com/spells:sorcerer), [Warlock](http://dnd5e.wikidot.com/spells:warlock), [Wizard](http://dnd5e.wikidot.com/spells:wizard)