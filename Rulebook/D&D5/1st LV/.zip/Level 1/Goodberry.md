Source: Player's Handbook

_1st-level transmutation_

**Casting Time:** 1 action  
**Range:** Touch  
**Components:** V, S, M (a sprig of mistletoe)  
**Duration:** Instantaneous

Up to ten berries appear in your hand and are infused with magic for the duration. A creature can use its action to eat one berry. Eating a berry restores 1 hit point, and the berry provides enough nourishment to sustain a creature for one day.

The berries lose their potency if they have not been consumed within 24 hours of the casting of this spell.

**_Spell Lists._** [Druid](http://dnd5e.wikidot.com/spells:druid), [Ranger](http://dnd5e.wikidot.com/spells:ranger)