Source: Player's Handbook

_1st-level transmutation_

**Casting Time:** 1 action  
**Range:** Touch  
**Components:** V, S, M (a grasshopper’s hind leg)  
**Duration:** 1 minute

You touch a creature. The creature’s jump distance is tripled until the spell ends.

**_Spell Lists._** [Artificer](http://dnd5e.wikidot.com/spells:artificer), [Druid](http://dnd5e.wikidot.com/spells:druid), [Ranger](http://dnd5e.wikidot.com/spells:ranger), [Sorcerer](http://dnd5e.wikidot.com/spells:sorcerer), [Wizard](http://dnd5e.wikidot.com/spells:wizard)