_1st-level abjuration_

**Casting Time:** 1 bonus action  
**Range:** 60 feet  
**Components:** V, S, M (a small parchment with a bit of holy text written on it)  
**Duration:** Concentration, up to 10 minutes

A shimmering field appears and surrounds a creature of your choice within range, granting it a +2 bonus to AC for the duration.

**_Spell Lists._** [Cleric](http://dnd5e.wikidot.com/spells:cleric), [Paladin](http://dnd5e.wikidot.com/spells:paladin)