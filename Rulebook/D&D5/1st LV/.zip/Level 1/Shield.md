_1st-level abjuration_

**Casting Time:** 1 reaction, which you take when you are hit by an attack or targeted by the [[Magic Missile]] spell
**Range:** Self  
**Components:** V, S  
**Duration:** 1 round

An invisible barrier of magical force appears and protects you. Until the start of your next turn, you have a +5 bonus to AC, including against the triggering attack, and you take no damage from _[magic missile](http://dnd5e.wikidot.com/spell:magic-missile)_.

**_Spell Lists._** [Sorcerer](http://dnd5e.wikidot.com/spells:sorcerer), [Wizard](http://dnd5e.wikidot.com/spells:wizard)