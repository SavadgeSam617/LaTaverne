Source: Unearthed Arcana 36 - Starter Spells

_1st-level conjuration_

**Casting Time:** 1 minute  
**Range:** Self  
**Components:** V, S, M (alchemist’s supplies)  
**Duration:** 24 hours

You create a healing elixir in a simple vial that appears in your hand. The elixir retains its potency for the duration or until it’s consumed, at which point the vial vanishes.

As an action, a creature can drink the elixir or administer it to another creature. The drinker regains 2d4 + 2 hit points.

**_Spell Lists._** [Warlock](http://dnd5e.wikidot.com/spells:warlock), [Wizard](http://dnd5e.wikidot.com/spells:wizard), [[Core Class; Artificer]]